
import UIKit
import MBProgressHUD

class ProgressLoader: NSObject {

    public class func showLoader(message:String, delegate: UIViewController) {
        var load : MBProgressHUD = MBProgressHUD()
        load = MBProgressHUD.showAdded(to: delegate.view, animated: true)
        load.mode = MBProgressHUDMode.indeterminate
        
        if message != "" {
            load.label.text = message;
        }
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        
    }
    
    public class func hideLoader(delegate:UIViewController) {
        MBProgressHUD.hide(for: delegate.view, animated: true)
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
    
}
