
import UIKit

class PendingCourcesTableViewCell: UITableViewCell {

    @IBOutlet weak var courceTypeLbl: UILabel!
    @IBOutlet weak var courcenameLbl: UILabel!
    @IBOutlet weak var courceselectionBtn: UIButton!

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
