
import UIKit

class ConfirmRequestViewController: UIViewController {

    @IBOutlet weak var aTableView: UITableView!
    
    var studentsRequests : NSMutableArray = []
    let cellReuseIdentifier = "cell"
    var delegate = UIApplication.shared.delegate as? AppDelegate
    var network = DataHelperClass()
    var selectedStudentName = String()
    var username = String()
    
    @IBAction func doneAction(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        network.delegate  = self
        self.getRequestforStudentsRequestedCourcesList(studentName: selectedStudentName )
    }
    
    func getRequestforStudentsRequestedCourcesList(studentName:String) -> Void {
        
        let urlString = String(format: "%@/displayrequestedcourses.php?username=%@", String.getBaseURL(),selectedStudentName)
        print(urlString)
        
        network.getAllStudentRequestedCourcesListByStudentName(withdelegate: self, url: urlString as NSString)
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
 
}

extension ConfirmRequestViewController:UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.studentsRequests.count>0 ? (self.studentsRequests.count) : 0
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : StudentRequestTableViewCell = (tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier, for: indexPath as IndexPath) as? StudentRequestTableViewCell)!
        
        
         let courceName = self.studentsRequests[indexPath.row] as! String
        
        cell.courceTypeLbl.text = courceName
        cell.acceptBtn.tag = indexPath.row
        cell.rejectBtn.tag = indexPath.row

        cell.acceptBtn.addTarget(self, action: #selector(self.courceRequestAccepted(sender:)), for: .touchUpInside)
        cell.rejectBtn.addTarget(self, action: #selector(self.courceRequestRejected(sender:)), for: .touchUpInside)
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        
        return 80;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       
    }
    
    func courceRequestAccepted(sender: UIButton!)
    {
        let value = sender.tag;
        print(value)
        
        //http://localhost/pvdatabase/approvecourse.php?username="+username+"&studentname="+username+"&coursename="+coursename+"&status1=PENDING
        let courceName = self.studentsRequests[value] as! String

        let urlString = String(format: "%@/approvecourse.php?username=%@&studentname=%@&coursename=%@&status1=PENDING", String.getBaseURL(),username,selectedStudentName,courceName)
        print(urlString)
        
        network.acceptStudentRequesteforCourseByCourceName(withdelegate: self, url: urlString as NSString)
        
    }
    
    func courceRequestRejected(sender: UIButton!)
    {
        let value = sender.tag;
        print(value)
        
        let courceName = self.studentsRequests[value] as! String
        
        let str = String(format: "Do you really want to reject %@?",courceName)
        
        self.showConfirmationAlert(title: "Confirm!", message: (str as NSString) as String, courceName: courceName)
    }
    
    func showSuccessAlert(title:NSString, message:NSString) -> Void {
        
        let alert = UIAlertController(title: title as String, message: message as String, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func showConfirmationAlert(title:String, message:String, courceName:String) -> Void {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        // add the actions (buttons)
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)

        }))

        alert.addAction(UIAlertAction(title: "Continue", style: UIAlertActionStyle.default, handler: { (action) in
            
            // http://localhost/pvdatabase/disapprovecourses.php?username="+username+"&studentname="+username+"&coursename="+coursename+"&status1=PENDING"
            let urlString = String(format: "%@/disapprovecourses.php?username=%@&studentname=%@&coursename=%@&status1=PENDING", String.getBaseURL(),self.username,self.selectedStudentName,courceName)
            print(urlString)
            
            self.network.rejectStudentRequesteforCourseByCourceName(withdelegate: self, url: urlString as NSString)
            alert.dismiss(animated: true, completion: nil)
        }))
        
        self.present(alert, animated: true, completion: nil)
        
    }

    
}

//MARK: DataHelper Delegate

extension ConfirmRequestViewController: DataHelperDelegate {
    
    func getResponse(tag: Int, responseData: AnyObject) {
        if tag == 8{
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                // print("JSON: \(responseData)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    self.showSuccessAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                }else{
                    
                     //print(jsonDict)
                    studentsRequests = NSMutableArray()

                    let dataArray = jsonDict.object(forKey: "record") as! NSArray
                    
                    for object in dataArray {
                        let  dictionary = object as! NSDictionary
                        let studentName = dictionary.value(forKey: "classid") as! NSString
                        studentsRequests.add(studentName)
                    }
                    
                    print(studentsRequests)
                    
                    let tblView =  UIView(frame: CGRect.zero)
                    self.aTableView.tableFooterView = tblView
                    self.aTableView.tableFooterView!.isHidden = true
                    self.aTableView.backgroundColor = UIColor.clear
                    
                    aTableView.delegate = self
                    aTableView.dataSource = self
                    self.aTableView.reloadData()
                    
                }
            }else{
                
                self.showSuccessAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                
            }
            
        }
        
        if tag == 9{
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["status"] != nil {
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    self.showSuccessAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                }else{
                    
                    print("JSON: \(jsonDict)")
                    
                    let status = jsonDict.object(forKey: "status") as! String
                    let message = jsonDict.object(forKey: "message") as! String

                    if status == "200" {
                        
                        self.showSuccessAlert(title: "SUCCESS", message:message as NSString)
                        self.getRequestforStudentsRequestedCourcesList(studentName: selectedStudentName)
                    }
                }
            }else{
                
                self.showSuccessAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
            }
        }
        
        if tag == 10{
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["status"] != nil {
                 print("JSON: \(jsonDict)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                }else{
                    
                    let status = jsonDict.object(forKey: "status") as! String
                    let message = jsonDict.object(forKey: "message") as! String
                    
                    
                    if status == "200" {
                        
                        self.showSuccessAlert(title: "SUCCESS", message:message as NSString)
                        self.getRequestforStudentsRequestedCourcesList(studentName: selectedStudentName )
                    }
                    
                }
            }else{
                
                self.showSuccessAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                
            }
            
        }
        
    }
}




