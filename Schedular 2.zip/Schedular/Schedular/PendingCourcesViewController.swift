
import UIKit
import MBProgressHUD

class PendingCourcesViewController: UIViewController {

    var parentNavigationController : UINavigationController?

    var network = DataHelperClass()
    var pendingCourcesArray : NSArray = []
    var selectedArray = NSMutableArray()
    var stringArray = NSMutableArray()

    var username = String()
    
    var delegate = UIApplication.shared.delegate as? AppDelegate
    
    @IBOutlet weak var aTableView: UITableView!
    @IBOutlet weak var withdrawCource: UIButton!

    @IBAction func withdrawCource_BtnAction(_ sender: Any) {
        
        ProgressLoader.showLoader(message: "Processing...", delegate: self)
        
        if selectedArray.count > 0 {
            
            for index in selectedArray{
                print(index)
                
                let courceDetails = self.pendingCourcesArray[index as! Int] as! NSDictionary
                let str = courceDetails.value(forKey: "classid") as! String
                stringArray.add(str)
            }
            
            // print(stringArray)
            
            let array = stringArray as NSArray
            let stringWithCommas = array.componentsJoined(by: ",")
            print(stringWithCommas)
            
            selectedArray = NSMutableArray()
            stringArray = NSMutableArray()
            
            self.postSelectedCourcesToWithdrawCources(username: username, courceName: stringWithCommas)
            
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        network.delegate = self
        
        if let data = UserDefaults.standard.value(forKey: "userInfo"){
            
            let userInfo = data as! NSDictionary
            print(userInfo)
            
            let array = userInfo.object(forKey: "record") as! NSArray
            let dict = array.object(at: 0) as! NSDictionary
            print(dict.value(forKey: "username") as! String)
            username = dict.value(forKey: "username") as! String
            
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
        
        self.sendGETRequestForAllPendingCources(username: username )

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.navigationItem.title = ""
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    func sendGETRequestForAllPendingCources(username:String) -> Void {
        
        let urlString = String(format: "%@/pendingcourses.php?username=%@", String.getBaseURL(),username)
        print(urlString)
        
        network.getAllPendingCources(withdelegate: self, url: urlString as NSString)
    }
    
    func postSelectedCourcesToWithdrawCources(username:String, courceName:String) -> Void {
        
        let urlString = String(format: "%@/withdrawcourses.php?username=%@&courses=%@,", String.getBaseURL(),username,courceName)
        print(urlString)
        
        network.postSelectedCourcesToWithdrawl(withdelegate: self, url: urlString as NSString)
        
    }
    
}



extension PendingCourcesViewController:UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.pendingCourcesArray.count>0 ? (self.pendingCourcesArray.count) : 0
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : PendingCourcesTableViewCell = (tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as? PendingCourcesTableViewCell)!
        
        
        let courceDetails = self.pendingCourcesArray[indexPath.row] as! NSDictionary
        
        cell.courceTypeLbl.text = courceDetails.value(forKey: "classid") as! String?
        cell.courcenameLbl.text = courceDetails.value(forKey: "classname") as! String?
        cell.courceselectionBtn.tag = indexPath.row
        cell.courceselectionBtn.addTarget(self, action: #selector(self.courceSelected(sender:)), for: .touchUpInside)
        
        if selectedArray .contains(indexPath.row) {
            cell.courceselectionBtn.setImage(UIImage(named:"check"), for: UIControlState.normal)
        }
        else
        {
            cell.courceselectionBtn.setImage(UIImage(named:"uncheck"), for: UIControlState.normal)
        }
        
        
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        
        return 60;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
    }
    
    func courceSelected(sender: UIButton!)
    {
        let value = sender.tag;
        
        if selectedArray.contains(value)
        {
            selectedArray.remove(value)
        }
        else
        {
            selectedArray.add(value)
        }
        
        print("Selecetd Array \(selectedArray)")
        
        aTableView.reloadData()
    }
}


//MARK: DataHelper Delegate

extension PendingCourcesViewController: DataHelperDelegate {
    
    func getResponse(tag: Int, responseData: AnyObject) {
        if tag == 14{
            
            ProgressLoader.hideLoader(delegate: self)
            
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
               // {"status":"400","message":"no courses requested"}
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    
                     let message = String(format: "%@", jsonDict.value(forKey: "message") as! CVarArg)
                    self.delegate?.showAlert(title: "Error!", message: message)
                    
                }else{
                    
                     print(jsonDict)
                    
                    self.pendingCourcesArray = NSArray()
                    self.pendingCourcesArray = jsonDict.object(forKey: "record") as! NSArray
                    print(pendingCourcesArray)
                    
                    let tblView =  UIView(frame: CGRect.zero)
                    self.aTableView.tableFooterView = tblView
                    self.aTableView.tableFooterView!.isHidden = true
                    self.aTableView.backgroundColor = UIColor.clear
                    
                    aTableView.delegate = self
                    aTableView.dataSource = self
                    self.aTableView.reloadData()
                    
                }
            }else{
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    let message = String(format: "%@", jsonDict.value(forKey: "message") as! CVarArg)
                    //self.delegate?.showAlert(title: "Error!", message: message)
                }
                
                
            }
            
        }else  if tag == 16{
            
                ProgressLoader.hideLoader(delegate: self)
            
                print("JSON: \(responseData)")
                selectedArray = NSMutableArray()
                self.sendGETRequestForAllPendingCources(username: username )

        }
        
    }
}



