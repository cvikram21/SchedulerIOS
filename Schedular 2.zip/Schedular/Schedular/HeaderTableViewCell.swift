
import UIKit

class HeaderTableViewCell: UITableViewCell {

    
    @IBOutlet weak var semester_Lbl: UILabel!
    @IBOutlet weak var creditHrs_Lbl: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
