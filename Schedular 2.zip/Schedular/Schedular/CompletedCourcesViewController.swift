
import UIKit
import MBProgressHUD

class CompletedCourcesViewController: UIViewController {

    var parentNavigationController : UINavigationController?
    
    var network = DataHelperClass()
    var completedCourcesArray : NSArray = []
    var username = String()
    
    var delegate = UIApplication.shared.delegate as? AppDelegate

    @IBOutlet weak var aTableView: UITableView!

   // http://localhost/pvdatabase/completedcourses.php?username=kjuluri
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ProgressLoader.showLoader(message: "Processing...", delegate: self)
        
        network.delegate = self
        
        if let data = UserDefaults.standard.value(forKey: "userInfo"){
            
            let userInfo = data as! NSDictionary
            print(userInfo)
            
            let array = userInfo.object(forKey: "record") as! NSArray
            let dict = array.object(at: 0) as! NSDictionary
            print(dict.value(forKey: "username") as! String)
            username = dict.value(forKey: "username") as! String
            
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
        
        self.sendGETRequestForAllCompletedCources(username: username )

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.navigationItem.title = ""
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func sendGETRequestForAllCompletedCources(username:String) -> Void {
        
        let urlString = String(format: "%@/completedcourses.php?username=%@", String.getBaseURL(),username)
        print(urlString)
        
        network.getAllCompletedCources(withdelegate: self, url: urlString as NSString)
        
    }


}

extension CompletedCourcesViewController:UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.completedCourcesArray.count>0 ? (self.completedCourcesArray.count) : 0
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : CompletedCourcesTableViewCell = (tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as? CompletedCourcesTableViewCell)!
        
        
        let courceDetails = self.completedCourcesArray[indexPath.row] as! NSDictionary
        
        cell.courceTypeLbl.text = courceDetails.value(forKey: "classid") as! String?
        cell.courcenameLbl.text = courceDetails.value(forKey: "classname") as! String?
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        
        return 60;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
    }
    
}

//MARK: DataHelper Delegate

extension CompletedCourcesViewController: DataHelperDelegate {
    
    func getResponse(tag: Int, responseData: AnyObject) {
        if tag == 13{
            ProgressLoader.hideLoader(delegate: self)
            
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                }else{
                    
                    // print(jsonDict)
                    
                    self.completedCourcesArray = jsonDict.object(forKey: "record") as! NSArray
                    print(completedCourcesArray)
                    
                    let tblView =  UIView(frame: CGRect.zero)
                    self.aTableView.tableFooterView = tblView
                    self.aTableView.tableFooterView!.isHidden = true
                    self.aTableView.backgroundColor = UIColor.clear
                    
                    aTableView.delegate = self
                    aTableView.dataSource = self
                    self.aTableView.reloadData()
                    
                    
                }
            }else{
                
                //self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again with valid credentials")
                
                
            }
            
        }
        
    }
}
