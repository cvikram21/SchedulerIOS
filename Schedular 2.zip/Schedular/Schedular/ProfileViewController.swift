
import UIKit
import Photos
import MobileCoreServices
import MBProgressHUD
import DropDown

class ProfileViewController: UIViewController,UITextFieldDelegate , UIActionSheetDelegate , UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIGestureRecognizerDelegate {

    var parentNavigationController : UINavigationController?

    var imagePicker = UIImagePickerController()
    var network = DataHelperClass()
    var sciseqArray : NSMutableArray = []

    var delegate = UIApplication.shared.delegate as? AppDelegate
    var username = String()
    var fname = String()
    var lname = String()
    var advisorname = String()
    var advisorfname = String()
    var advisorlname = String()
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var profile_imageview: UIImageView!
    @IBOutlet weak var sciseqIDFld: UITextField!
    @IBOutlet weak var deptIDFld: UITextField!
    @IBOutlet weak var adviserFld: UITextField!
    @IBOutlet weak var phoneFld: UITextField!
    @IBOutlet weak var sciseq_Lbl: UILabel!
    
    @IBOutlet weak var modify_Btn: UIButton!
    
    //MARK: - DropDown's
    
    let chooseDepartmentDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.chooseDepartmentDropDown
        ]
    }()
    
    func setupDefaultDropDown() {
        DropDown.setupDefaultAppearance()
        
        dropDowns.forEach {
            $0.cellNib = UINib(nibName: "DropDownCell", bundle: Bundle(for: DropDownCell.self))
            $0.customCellConfiguration = nil
        }
    }
    
    //MARK: - Setup
    
    func setupDropDowns() {
        setupCenteredDropDown()
    }
    
    func setupCenteredDropDown() {
        
        print((self.sciseqArray as NSArray) as! [String])
        
        chooseDepartmentDropDown.dataSource = (self.sciseqArray as NSArray) as! [String]
        
        // Action triggered on selection
        chooseDepartmentDropDown.selectionAction = { [unowned self] (index, item) in
            self.sciseqIDFld.text = item
            self.sciseq_Lbl.text = item
        }
    }
    
    @IBAction func modify_BtnAction(_ sender: Any) {
        
        
        if modify_Btn.currentTitle == "Modify" {
            
            sciseqIDFld.isUserInteractionEnabled = true
            deptIDFld.isUserInteractionEnabled = true
            adviserFld.isUserInteractionEnabled = true
            phoneFld.isUserInteractionEnabled = true
            
            sciseqIDFld.becomeFirstResponder()
            modify_Btn.setTitle("Update", for: .normal)
            
        }else{
            
            ProgressLoader.showLoader(message: "Processing...", delegate: self)

            sciseqIDFld.isUserInteractionEnabled = false
            deptIDFld.isUserInteractionEnabled = false
            adviserFld.isUserInteractionEnabled = false
            phoneFld.isUserInteractionEnabled = false

            modify_Btn.setTitle("Modify", for: .normal)
            
            self.updateStudentDetails(username: username)
            
        }
    }
    
    func updateStudentDetails(username:String) -> Void {
        
       // http://localhost/pvdatabase/updatestudentinfo.php?username=”+userPref.getString(“name”,null)+”&department=”+s8+”&advisorname=”+s9+”&sciseqid=”+s7+”&phone=”+s8.getText().toString()+””
        
        let urlString = String(format: "%@/updatestudentinfo.php?username=%@&department=%@&advisorname=%@&sciseqid=%@&phone=%@", String.getBaseURL(),username,deptIDFld.text!,adviserFld.text!,sciseqIDFld.text!,phoneFld.text!)
        print(urlString)
        
        network.updateStudentProfile(withdelegate: self, url: urlString as NSString)
        
    }
    
    
    func changeProfilePic_TouchUpInside(_ sender: Any) {
        
        
        //Create the AlertController and add Its action like button in Actionsheet
        let actionSheetController: UIAlertController = UIAlertController(title: "Please select", message: "", preferredStyle: .actionSheet)
        
        let cameraActionButton: UIAlertAction = UIAlertAction(title: "Camera", style: .default) { action -> Void in
            self.openCamera()
            
        }
        actionSheetController.addAction(cameraActionButton)
        
        let libraryActionButton: UIAlertAction = UIAlertAction(title: "Library", style: .default)
        { action -> Void in
            self.openGallary()
        }
        actionSheetController.addAction(libraryActionButton)
        
        let cancelActionButton: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel)
        { action -> Void in
        }
        actionSheetController.addAction(cancelActionButton)
        
        
        self.present(actionSheetController, animated: true, completion: nil)
        
    }
    
        override func viewDidLoad() {
            super.viewDidLoad()
            
           // ProgressLoader.showLoader(message: "Loading...", delegate: self)
            
            sciseqArray = ["Sciseq 1","Sciseq 2","Sciseq 3"]

            network.delegate = self
            
            sciseqIDFld.setLeftPaddingPoints(5)
            adviserFld.setLeftPaddingPoints(5)
            phoneFld.setLeftPaddingPoints(5)
            deptIDFld.setLeftPaddingPoints(5)

            self.imagePicker.delegate = self
            self.profile_imageview.isUserInteractionEnabled = true
            
         /*   let gesture = UITapGestureRecognizer(target: self, action: #selector(self.changeProfilePic_TouchUpInside(_:)))
            gesture.delegate = self
            gesture.numberOfTapsRequired = 1
            self.profile_imageview.addGestureRecognizer(gesture)*/
            

            
            if let data = UserDefaults.standard.value(forKey: "userInfo"){
                
                let userInfo = data as! NSDictionary
                print(userInfo)
                
                let array = userInfo.object(forKey: "record") as! NSArray
                let dict = array.object(at: 0) as! NSDictionary
                username = dict.value(forKey: "username") as! String
                fname = dict.value(forKey: "fname") as! String
                lname = dict.value(forKey: "lname") as! String
                advisorfname = dict.value(forKey: "advisorfname") as! String
                advisorlname = dict.value(forKey: "advisorlname") as! String
                advisorname = advisorfname+" "+advisorlname
                let aStr = String(format: "Welcome, %@", fname )
                nameLbl.text = aStr
                
                sciseqIDFld.text = dict.value(forKey: "sciseqid") as? String
                adviserFld.text = advisorname
                deptIDFld.text = dict.value(forKey: "department") as? String
                phoneFld.text = dict.value(forKey: "phone") as? String
                
            }
            
            sciseqIDFld.isUserInteractionEnabled = false
            adviserFld.isUserInteractionEnabled = false
            deptIDFld.isUserInteractionEnabled = false
            phoneFld.isUserInteractionEnabled = false

            let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ModifyStudentDetailsViewController.dismissKeyboard))
            
            //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
            //tap.cancelsTouchesInView = false
            
            view.addGestureRecognizer(tap)

        }
        
        override func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)
        }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        ProgressLoader.hideLoader(delegate: self)

        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.navigationItem.title = ""
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }

    
    
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            self.imagePicker.sourceType = UIImagePickerControllerSourceType.camera
            self.imagePicker.allowsEditing = true
            
            self .present(self.imagePicker, animated: true, completion: nil)
        }
        else
        {
            //Error
            self.delegate?.showAlert(title: "Warning!", message: "Your device doesn't support camera")
            
        }
    }
    func openGallary()
    {
        self.imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        self.imagePicker.allowsEditing = true
        self.present(self.imagePicker, animated: true, completion: nil)
    }
    
    private func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject])
    {
        if let image = info[UIImagePickerControllerEditedImage] as? UIImage
        {

            self.profile_imageview.layer.cornerRadius = self.profile_imageview.frame.size.width / 2
            self.profile_imageview.clipsToBounds = true
            self.profile_imageview.image = image
            
            picker .dismiss(animated: true, completion: nil)
        }
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        picker .dismiss(animated: true, completion: nil)
    }
    
    
    // MARK: - Delegate
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == sciseqIDFld{
            
            self.setupDropDowns()
            chooseDepartmentDropDown.show()

            return false
        }else{
            return true
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Validate the username and email field
        
        // When pressing return, move to the next field
        let nextTag = textField.tag + 1
        if let nextResponder = textField.superview?.viewWithTag(nextTag) as UIResponder! {
            nextResponder.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        
        return true
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}


//MARK: DataHelper Delegate

extension ProfileViewController: DataHelperDelegate {
    
    func getResponse(tag: Int, responseData: AnyObject) {
        if tag == 11{
            
            ProgressLoader.hideLoader(delegate: self)

            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["status"] != nil {
                
                 print("JSON: \(responseData)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{

                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                }else{
                    
                    let mesaage = jsonDict.value(forKey: "message") as? String
                    
                    self.delegate?.showAlert(title: "Success", message: mesaage!)
                    
                }
            }else{
                
                
                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
            }
        }
        
    }
}

