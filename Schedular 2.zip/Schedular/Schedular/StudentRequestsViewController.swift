
import UIKit
import MBProgressHUD

class StudentRequestsViewController: UIViewController {

    @IBOutlet weak var aTableView: UITableView!
    
    var studentsArray : NSMutableArray = []
    let cellReuseIdentifier = "cell"
    var delegate = UIApplication.shared.delegate as? AppDelegate
    var network = DataHelperClass()
    var selectedStudentName = String()
    var username = String()

    //http://localhost/pvdatabase/displayrequests.php?username="+user
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let loadingNotification = MBProgressHUD.showAdded(to: self.view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.indeterminate
        loadingNotification.label.text = "Loading..."

        
        network.delegate = self
        
        if let data = UserDefaults.standard.value(forKey: "userInfo"){
            
            let userInfo = data as! NSDictionary
            print(userInfo)
            
            let array = userInfo.object(forKey: "record") as! NSArray
            let dict = array.object(at: 0) as! NSDictionary
            print(dict.value(forKey: "username") as! String)
            username = dict.value(forKey: "username") as! String
            
            self.getRequestforStudentsRequestsList(username: username )
            
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.navigationItem.title = ""
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    func getRequestforStudentsRequestsList(username:String) -> Void {
        
        let urlString = String(format: "%@/displayrequests.php?username=%@", String.getBaseURL(),username)
        print(urlString)
        
        network.getAllStudentsRequestsListByAdvisor(withdelegate: self, url: urlString as NSString)
        
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

extension StudentRequestsViewController:UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.studentsArray.count>0 ? (self.studentsArray.count) : 0
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier) as UITableViewCell!
        
        
        let studentName = self.studentsArray[indexPath.row] as! String
        
        cell.textLabel?.text = studentName
        
        return cell;
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedStudentName = studentsArray.object(at: indexPath.row) as! String
        print(selectedStudentName)
        
        self.performSegue(withIdentifier: "CourceRequestIdentifier", sender: selectedStudentName)

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "CourceRequestIdentifier") {
            
            let viewController:ConfirmRequestViewController = segue.destination as! ConfirmRequestViewController
            viewController.selectedStudentName = selectedStudentName
            viewController.username = username
            
        }
        
    }
}



//MARK: DataHelper Delegate

extension StudentRequestsViewController: DataHelperDelegate {
    
    func getResponse(tag: Int, responseData: AnyObject) {
        if tag == 7{
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                
                // print("JSON: \(responseData)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    MBProgressHUD.hide(for: self.view, animated: true)
                    self.delegate?.showAlert(title: "Error!", message: "No requests were found at this moment")
                }else{
                    
                    // print(jsonDict)
                    
                    let dataArray = jsonDict.object(forKey: "record") as! NSArray
                    
                    for object in dataArray {
                        let  dictionary = object as! NSDictionary
                        let studentName = dictionary.value(forKey: "user") as! NSString
                        studentsArray.add(studentName)
                    }
                    
                    print(studentsArray)
                    
                    let tblView =  UIView(frame: CGRect.zero)
                    self.aTableView.tableFooterView = tblView
                    self.aTableView.tableFooterView!.isHidden = true
                    self.aTableView.backgroundColor = UIColor.clear
                    
                    aTableView.delegate = self
                    aTableView.dataSource = self
                    self.aTableView.reloadData()
                    MBProgressHUD.hide(for: self.view, animated: true)

                    
                }
            }else{
                MBProgressHUD.hide(for: self.view, animated: true)
                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                
            }
            
        }
        
    }
}



