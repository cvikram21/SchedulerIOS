
import UIKit

class HomePageViewController: UIViewController,CAPSPageMenuDelegate {
    
    var pageMenu : CAPSPageMenu?
    var controllerArray : [UIViewController] = []
    var parameters: [CAPSPageMenuOption] = []
    var message = String()
    var userInfo = NSDictionary()
    var loginType = String()
    
    var type = Bool()
    
    
    var delegate = UIApplication.shared.delegate as? AppDelegate


    override func viewDidLoad() {
        super.viewDidLoad()
        type = false
        //message = "Message from PHP\nMessage from PHP"
        self.navigationItem.hidesBackButton = true
        self.navigationItem.title = NSLocalizedString("SCHEDULER", comment: "SCHEDULER")
        
        let rightBarBtn = UIButton(type: .custom)
        rightBarBtn.setImage(UIImage(named: "Logout"), for: .normal)
        rightBarBtn.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        rightBarBtn.addTarget(self, action: #selector(self.logoutFromApp), for: .touchUpInside)
        let rightBarBtnItem = UIBarButtonItem(customView: rightBarBtn)
        self.navigationItem.setRightBarButtonItems([rightBarBtnItem], animated: true)
        
        let leftBarBtn = UIButton(type: .custom)
        leftBarBtn.setImage(UIImage(named: "faq"), for: .normal)
        leftBarBtn.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        leftBarBtn.addTarget(self, action: #selector(self.faqPopUp), for: .touchUpInside)
        let leftBarBtnItem = UIBarButtonItem(customView: leftBarBtn)
        self.navigationItem.setLeftBarButtonItems([leftBarBtnItem], animated: true)

        
        
        self.setupCustomSwipeMenu()
    }
    
    func setupCustomSwipeMenu() -> Void {
        
        if let data = UserDefaults.standard.value(forKey: "userInfo"){
            
            userInfo = data as! NSDictionary
            print(userInfo)
            
            loginType = userInfo.value(forKey: "message") as! String
        }
        
        if loginType == "faculty"  {
            
            let home:FacultyHomeViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "FacultyHomeViewController") as UIViewController as! FacultyHomeViewController
            home.title = "HOME"
            controllerArray.append(home)
            
            let students:StudentsListViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "StudentsListViewController") as UIViewController as! StudentsListViewController
            students.title = "ADVISEES"
          
            controllerArray.append(students)
            
            
            let studentRequests:StudentRequestsViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "StudentRequestsViewController") as UIViewController as! StudentRequestsViewController
            studentRequests.title = "REQUESTS"
           
            controllerArray.append(studentRequests)
            
            type = false
            
            
        }else{
 
        let home:ProfileViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProfileViewController") as UIViewController as! ProfileViewController
        home.parentNavigationController = self.navigationController
        home.title = "HOME"
        controllerArray.append(home)
        
        let courses:CourcesViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CourcesViewController") as! CourcesViewController
        courses.parentNavigationController = self.navigationController
        courses.title = "COURSES"
        controllerArray.append(courses)
        
        let pendingCourses:PendingCourcesViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PendingCourcesViewController") as UIViewController as! PendingCourcesViewController
        pendingCourses.parentNavigationController = self.navigationController
        pendingCourses.title = "PENDING COURSES"
        controllerArray.append(pendingCourses)
        
        let completedCourses:CompletedCourcesViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CompletedCourcesViewController") as UIViewController as! CompletedCourcesViewController
        completedCourses.parentNavigationController = self.navigationController
        completedCourses.title = "COMPLETED COURSES"
        controllerArray.append(completedCourses)
        
        let schedules:SchedulesViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SchedulesViewController") as UIViewController as! SchedulesViewController
        schedules.parentNavigationController = self.navigationController
        schedules.title = "SCHEDULE"
        controllerArray.append(schedules)
            
            type = true
            
     }
        
        // Customize menu (Optional)
        parameters = [
            .scrollMenuBackgroundColor(UIColor.init(colorLiteralRed: 6/255, green: 52/255, blue: 58/255, alpha: 1.0)),
            .viewBackgroundColor(UIColor.init(colorLiteralRed: 6/255, green: 52/255, blue: 58/255, alpha: 1.0)),
            .selectionIndicatorColor(UIColor.orange),
            .addBottomMenuHairline(true),
            .menuItemFont(UIFont(name: "Avenir", size: 18.0)!),
            .menuHeight(50.0),
            .selectionIndicatorHeight(2.0),
            .selectedMenuItemLabelColor(UIColor.white),
            .menuItemSeparatorColor(UIColor.white),
            .menuItemSeparatorWidth(2.0),
            .menuItemWidthBasedOnTitleTextWidth(type)
        ]
        
        let rect = CGRect(x: 0.0, y: 0.0, width: self.view.frame.width, height: self.view.frame.height) // CGFloat, Double, Int

        // Initialize scroll menu
        pageMenu = CAPSPageMenu(viewControllers: controllerArray, frame: rect, pageMenuOptions: parameters)
        self.view.addSubview(pageMenu!.view)
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func logoutFromApp() -> Void {
        
        self.showConfirmationAlert(title: "Confirmation", message: "Do you really wants to logout from the app!")
        
    }
    
    func faqPopUp() -> Void {
        
        
        let urlString = String(format: "%@/faqs.php?", String.getBaseURL())
        print(urlString)
        
        //network.getFaqs(withdelegate: self, url: urlString as NSString)
        
        
        
        
        let url = URL(string: "http://pvdatabase.000webhostapp.com/pvdatabase/faqs.php?")
        
        
        let task1 = URLSession.shared.dataTask(with: url!) {
            (data, response, error) -> Void in
            
            if let urlResults = data {
                
                do {
                    
                    let searchResults1 = try JSONSerialization.jsonObject(with: urlResults, options: JSONSerialization.ReadingOptions.mutableContainers)
                    
                    //print(searchResults)
                    
                    let status = (searchResults1 as AnyObject).value(forKey: "status") as? String
                    let message1 = (searchResults1 as AnyObject).value(forKey: "message") as? String
                    let message2 = (searchResults1 as AnyObject).value(forKey: "facultymessage") as? String
                    if status == "200" {
                        print("IN 200")
                        if self.loginType == "faculty"{
                        self.message = message2!
                            let alert = UIAlertController(title: "FAQ", message: self.message, preferredStyle: UIAlertControllerStyle.alert)
                            alert.addAction(UIAlertAction(title: "Close", style: UIAlertActionStyle.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                            
                        }
                        else{
                        self.message = message1!
                        let alert = UIAlertController(title: "FAQ", message: self.message, preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "Close", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        }
                    }else{
                        self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                        
                    }
                    
                } catch let error as NSError{
                    
                    print("error occured in do"+error.localizedDescription)
                    
                }
            }
            
        }
        task1.resume()

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
    
    // MARK: - Helpers
    
    func showConfirmationAlert(title: String, message:String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
        }))
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
            var userInfo = UserDefaults.standard.value(forKey: "userInfo")
            let emptyDictionary = [String: String]()
            userInfo = emptyDictionary
            self.delegate?.defaults.set(userInfo, forKey: "userInfo")
            
            guard self.navigationController?.popToRootViewController(animated: true) != nil
                else {
                    print("No Navigation Controller")
                    return
            }
            
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
}





