

import UIKit
import Alamofire
import SwiftyJSON

protocol DataHelperDelegate: class {
    
    func getResponse(tag:Int, responseData:AnyObject)
}

class DataHelperClass: NSObject {
    
    weak var delegate: DataHelperDelegate?
    
    //MARK:-Login Data Layer


    func loginAsStudent(withdelegate delegate:DataHelperDelegate, url:NSString, parameters:NSDictionary){
        
        let urlString = String(format: "%@username=%@&password=%@", url,parameters.value(forKey: "username") as! CVarArg,parameters.value(forKey: "password") as! CVarArg)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print(" JSON: \(JSON)")
                self.delegate?.getResponse(tag: 1, responseData: JSON as AnyObject)
            }
        }
    }
  
    func loginAsFaculty(withdelegate delegate:DataHelperDelegate, url:NSString, parameters:NSDictionary){

        let urlString = String(format: "%@username=%@&password=%@", url,parameters.value(forKey: "username") as! CVarArg,parameters.value(forKey: "password") as! CVarArg)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print(" JSON: \(JSON)")
                self.delegate?.getResponse(tag: 2, responseData: JSON as AnyObject)
            }
        }
    }
    
    //MARK:-Registration Data Layer
    
    func registerAsFaculty(withBaseURL url:NSString, parameters:NSDictionary) {
        
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print("Faculty Register JSON: \(JSON)")
                self.delegate?.getResponse(tag: 20, responseData: JSON as AnyObject)
            }
        }
    }

    func registerAsStudent(withBaseURL url:NSString, parameters:NSDictionary) {
        
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print("Student Register JSON: \(JSON)")
                self.delegate?.getResponse(tag: 2, responseData: JSON as AnyObject)
            }
        }
    }
    
    func getAllDepartments(withdelegate delegate:DataHelperDelegate, url:NSString){
      
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
               // print("Faculty JSON: \(JSON)")
                self.delegate?.getResponse(tag: 3, responseData: JSON as AnyObject)
            }
        }
    }
    
    
    func getAllServiceIDsWithUsername(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                // print("Faculty JSON: \(JSON)")
                self.delegate?.getResponse(tag: 18, responseData: JSON as AnyObject)
            }
        }
    }

    
    func getAllAdviserIDsWithServiceID(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                // print("Faculty JSON: \(JSON)")
                self.delegate?.getResponse(tag: 19, responseData: JSON as AnyObject)
            }
        }
    }

    //MARK:-Faculty Data Layer
    
    func getAllStudentsForTheAdvisor(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                // print("Faculty JSON: \(JSON)")
                self.delegate?.getResponse(tag: 4, responseData: JSON as AnyObject)
            }
        }
    }
    
    func getStudentDetailsWithStudentName(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print(" JSON: \(JSON)")
                self.delegate?.getResponse(tag: 5, responseData: JSON as AnyObject)
            }
        }
    }
    
    func updateStudentDetailsWithStudentName(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print(" JSON: \(JSON)")
                self.delegate?.getResponse(tag: 6, responseData: JSON as AnyObject)
            }
        }
    }
    
    func getFaqs(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
               print(" JSON: \(JSON)")
                self.delegate?.getResponse(tag: 201, responseData: JSON as AnyObject)
            }
        }
    }
    
    func getAllStudentsRequestsListByAdvisor(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                // print("Faculty JSON: \(JSON)")
                self.delegate?.getResponse(tag: 7, responseData: JSON as AnyObject)
            }
        }
    }
    
    func getAllStudentRequestedCourcesListByStudentName(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                // print("Faculty JSON: \(JSON)")
                self.delegate?.getResponse(tag: 8, responseData: JSON as AnyObject)
            }
        }
    }
    
    func acceptStudentRequesteforCourseByCourceName(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                // print("Faculty JSON: \(JSON)")
                self.delegate?.getResponse(tag: 9, responseData: JSON as AnyObject)
            }
        }
    }

    func rejectStudentRequesteforCourseByCourceName(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                // print("Faculty JSON: \(JSON)")
                self.delegate?.getResponse(tag: 10, responseData: JSON as AnyObject)
            }
        }
    }
    
    func updateStudentProfile(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print(" JSON: \(JSON)")
                self.delegate?.getResponse(tag: 11, responseData: JSON as AnyObject)
            }
        }
    }
    
    func getAllCources(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print(" JSON: \(JSON)")
                self.delegate?.getResponse(tag: 12, responseData: JSON as AnyObject)
            }
        }
    }

    func getAllCompletedCources(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print(" JSON: \(JSON)")
                self.delegate?.getResponse(tag: 13, responseData: JSON as AnyObject)
            }
        }
    }
    
    func getAllPendingCources(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print(" JSON: \(JSON)")
                self.delegate?.getResponse(tag: 14, responseData: JSON as AnyObject)
            }
        }
    }
    
    func postSelectedCourcesForApproval(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print("selected cources JSON: \(JSON)")
                self.delegate?.getResponse(tag: 15, responseData: JSON as AnyObject)
            }
        }
    }
    
    func postSelectedCourcesToWithdrawl(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
                print("cources JSON: \(JSON)")
                self.delegate?.getResponse(tag: 16, responseData: JSON as AnyObject)
            }
        }
    }
    
    func getAlltheSchedulesOfStudent(withdelegate delegate:DataHelperDelegate, url:NSString){
        
        let urlString = String(format: "%@", url)
        print(urlString)
        
        Alamofire.request(urlString).responseJSON { response in
            print(response.result)
            if let JSON = response.result.value {
               // print("Schedules JSON: \(JSON)")
                self.delegate?.getResponse(tag: 17, responseData: JSON as AnyObject)
            }
        }
    }


}
