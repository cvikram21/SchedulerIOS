
import UIKit
import DropDown

class FacultyRegistrationViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var aSrollView: UIScrollView!
    var activeField: UITextField?
    var network = DataHelperClass()
    var departmentsArray : NSMutableArray = []
    var isCoordinator:Bool = false
    var delegate = UIApplication.shared.delegate as? AppDelegate

    
    @IBOutlet weak var coordinatorBtn: UIButton!
    @IBOutlet weak var idFld: UITextField!
    @IBOutlet weak var firstNameFld: UITextField!
    @IBOutlet weak var lastNameFld: UITextField!
    @IBOutlet weak var emailFld: UITextField!
    @IBOutlet weak var aPasswordFld: UITextField!
    @IBOutlet weak var aConfirmPwdFld: UITextField!
    @IBOutlet weak var aPhonenumberFld: UITextField!

    @IBOutlet weak var chooseDepartmentButton: UIButton!
    @IBOutlet weak var aSubmitBtn: UIButton!

    //MARK: - DropDown's
    
    let chooseDepartmentDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.chooseDepartmentDropDown
        ]
    }()
    
    func setupDefaultDropDown() {
        DropDown.setupDefaultAppearance()
        
        dropDowns.forEach {
            $0.cellNib = UINib(nibName: "DropDownCell", bundle: Bundle(for: DropDownCell.self))
            $0.customCellConfiguration = nil
        }
    }
    
    //MARK: - Setup
    
    func setupDropDowns() {
        setupCenteredDropDown()
    }
    
    func setupCenteredDropDown() {
      
        print((self.departmentsArray as NSArray) as! [String])
        
        chooseDepartmentDropDown.dataSource = (self.departmentsArray as NSArray) as! [String]
        
        // Action triggered on selection
        chooseDepartmentDropDown.selectionAction = { [unowned self] (index, item) in
            self.chooseDepartmentButton.setTitle(item, for: .normal)
        }
    }

    @IBAction func chooseDepartmentAction(_ sender: Any) {
        
        chooseDepartmentDropDown.show()
        
    }
    
    @IBAction func selectCoordinator(_ sender: Any) {
        
        let btn = sender as! UIButton
        let image = UIImage(named:"uncheck")

        if (image == btn.currentImage) {
            self.coordinatorBtn.setImage(UIImage(named:"check"), for: UIControlState.normal)
            self.isCoordinator = true
        }else{
    
            self.coordinatorBtn.setImage(UIImage(named:"uncheck"), for: UIControlState.normal)
            self.isCoordinator = false

          }
    }
    
    
    @IBAction func aSubmitDetailsToRegister_TouchUpInside(_ sender: Any) {
        
        print(self.isCoordinator)
        if self.idFld.hasText && self.firstNameFld.hasText && self.lastNameFld.hasText && self.emailFld.hasText && self.aPasswordFld.hasText && self.aPhonenumberFld.hasText{
            
            if (self.delegate?.isPwdLenth(password: self.aPasswordFld.text!, confirmPassword: self.aConfirmPwdFld.text!))!{
                
                if (self.delegate?.isPasswordSame(password: self.aPasswordFld.text!, confirmPassword: self.aConfirmPwdFld.text!))! {
                    
                    if (self.delegate?.validatePhoneNumber(value: self.aPhonenumberFld.text!))! {
                        
                        if (self.delegate?.isValidFacultyEmail(testStr: self.emailFld.text!))! {
                            
                            print("Validate EmailID")
                            self.registerAsFaculty()
                        }
                        else{
                            
                            self.delegate?.showAlert(title: "Error!", message: "Please enter valid email, make sure you register with your PV mail")
                            return
                        }
                        
                    }else{
                        
                        self.delegate?.showAlert(title: "Error!", message: "Please enter valid phone number")
                        return
                    }

                }else{
                    
                    self.delegate?.showAlert(title: "Error!", message: "Password should be match")
                    return
                }
                
            }else{
                
                self.delegate?.showAlert(title: "Error!", message: "Password should be more than 7 characters")
                return
            }
            
        }else{
            
            self.delegate?.showAlert(title: "Error!", message: "Please enter valid username and password ")
        }

    }
    
    func registerAsFaculty() -> Void {
        
        ProgressLoader.showLoader(message: "Processing...", delegate: self)
        
        
        var department = self.chooseDepartmentButton.currentTitle!
        
        if(department == "COMPUTERSCIENCE"){
            department = "d101";}
        if(department == "ELECTRICALENGINEERING"){
            department = "d102";}
        if(department == "CIVILENGINEERING"){
            department = "d103";}
        if(department == "MECHANICALENGINEERING"){
            department = "d104";}
        if(department == "BUSINESSMANAGEMENT"){
            department = "d105";}
        
        
        let parameterDict : NSDictionary  = ["advisorid":self.idFld.text!,
                                             "firstname":self.firstNameFld.text!,
                                             "lastname":self.lastNameFld.text!,
                                             "email":self.emailFld.text!,
                                             "password":self.aPasswordFld.text!,
                                             "phone":self.aPhonenumberFld.text!,
                                             "deptid":department,
                                             "isCoordinator":self.isCoordinator]
        print("params:\(parameterDict)")
        
        // http://localhost/pvdatabase/facultysignup.php?advisorid="+s1+"&firstname="+s2+"&lastname="+s3+"&email="+s4+"&password="+s5+"&phone="+s6+"&sdeptid="+s7+""
        let urlString = String(format: "%@/facultysignup.php?advisorid=%@&firstname=%@&lastname=%@&email=%@&password=%@&phone=%@&deptid=%@&coordinator=%@", String.getBaseURL(),self.idFld.text!,self.firstNameFld.text!,self.lastNameFld.text!,self.emailFld.text!,self.aPasswordFld.text!,self.aPhonenumberFld.text!,department,self.isCoordinator as CVarArg)
        print(urlString)
        
        network.registerAsFaculty(withBaseURL: urlString as NSString, parameters: parameterDict)
        
    }
    
    func getAllDepartments() -> Void {

        let urlString = String(format: "%@/updateddepartments.php?", String.getBaseURL())
        print(urlString)
        
        network.getAllDepartments(withdelegate: self, url: urlString as NSString)
        
    }
    
    // MARK: - VIewcontroller LifeCycles
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ProgressLoader.showLoader(message: "Processing...", delegate: self)

        network.delegate = self
        self.aSrollView.contentInset = UIEdgeInsetsMake(0, 0, 220, 0);
        
        self.navigationItem.title = "REGISTER AS FACULTY"
        
        dropDowns.forEach { $0.dismissMode = .onTap }
        dropDowns.forEach { $0.direction = .any }

        
        idFld.delegate = self
        firstNameFld.delegate = self
        lastNameFld.delegate = self
        emailFld.delegate = self
        aPasswordFld.delegate = self
        aConfirmPwdFld.delegate = self
        
        idFld.setLeftPaddingPoints(5)
        firstNameFld.setLeftPaddingPoints(5)
        lastNameFld.setLeftPaddingPoints(5)
        emailFld.setLeftPaddingPoints(5)
        aPasswordFld.setLeftPaddingPoints(5)
        aConfirmPwdFld.setLeftPaddingPoints(5)
        
        
        self.registerForKeyboardNotifications()
        self.getAllDepartments()
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ModifyStudentDetailsViewController.dismissKeyboard))
        
        //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
        //tap.cancelsTouchesInView = false
        
        view.addGestureRecognizer(tap)

    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.navigationItem.title = ""
        self.deregisterFromKeyboardNotifications()

    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }

    
    // MARK: - Keyboard Notifications Delegate
   
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.aSrollView.isScrollEnabled = true
        var info = notification.userInfo!
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height, 0.0)
        
        self.aSrollView.contentInset = contentInsets
        self.aSrollView.scrollIndicatorInsets = contentInsets
        
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.aSrollView.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }
    
    func keyboardWillBeHidden(notification: NSNotification){
        //Once keyboard disappears, restore original positions
        var info = notification.userInfo!
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, -keyboardSize!.height, 0.0)
        self.aSrollView.contentInset = contentInsets
        self.aSrollView.scrollIndicatorInsets = contentInsets
        self.view.endEditing(true)
        //self.aSrollView.isScrollEnabled = false
    }
    
    // MARK: - UITextField Delegate
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        // When pressing return, move to the next field
        let nextTag = textField.tag + 1
        if let nextResponder = textField.superview?.viewWithTag(nextTag) as UIResponder! {
            nextResponder.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        self.aSrollView.contentInset = UIEdgeInsetsMake(0, 0, 220, 0);

        
        return true
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        activeField = textField
    }
    
    func textFieldDidEndEditing(_ textField: UITextField){
        
        activeField = nil
    }
    
    
    func validateEmail(candidate: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"
        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: candidate)
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        return true
    }
    
    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "aHomepageIdentifier") {
            
            let viewController:HomePageViewController = segue.destination as! HomePageViewController
            print(viewController)
            
        }
        
    }

}

//MARK: DataHelper Delegate

extension FacultyRegistrationViewController: DataHelperDelegate {
    
    func getResponse(tag: Int, responseData: AnyObject) {
        
        ProgressLoader.hideLoader(delegate: self)
        if tag == 3{
            
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                
               // print("JSON: \(responseData)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again")
                }else{
                   
                    let dataArray = jsonDict.object(forKey: "record") as! NSArray
                    
                    print(dataArray)
                    
                    for object in dataArray {
                        let  dictionary = object as! NSDictionary
                        let deptname = dictionary.value(forKey: "deptname") as! NSString
                        departmentsArray.add(deptname)
                    }
                    
                    self.setupDropDowns()
                
                }
            }
        }
        
        if tag == 20{
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                
                // print("JSON: \(responseData)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                let message = jsonDict.value(forKey: "message") as! NSString
                if(status == "400" && message == "registered"){
                    self.delegate?.showAlert(title: "Error!", message: "Email already registered")
                }
                else if status == "400"{
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again")
                }else if status == "200"{
                    
                    let dataArray = jsonDict.object(forKey: "record") as! NSArray
                    
                    print(dataArray)
                    self.delegate?.showAlert(title: "Success!", message: "Your account has been successfully registered, please check your email to verify your account")
                    
                    
                    self.performSegue(withIdentifier: "aHomeidentifier", sender: self)
                    
                }
            }
        }
        
    }
}



