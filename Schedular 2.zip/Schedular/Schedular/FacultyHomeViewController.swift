
import UIKit
import MBProgressHUD

class FacultyHomeViewController: UIViewController {

    @IBOutlet weak var aFacultyName: UILabel!
    @IBOutlet weak var aFacultyProfilePic: UIImageView!
    @IBOutlet weak var aFacultyEmailFld: UITextField!
    @IBOutlet weak var aFacultyNameFld: UITextField!
    @IBOutlet weak var aFacultyMobileFld: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let loadingNotification = MBProgressHUD.showAdded(to: self.view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.indeterminate
        loadingNotification.label.text = "Loading..."

        aFacultyEmailFld.setLeftPaddingPoints(5)
        aFacultyNameFld.setLeftPaddingPoints(5)
        aFacultyMobileFld.setLeftPaddingPoints(5)

        
        if let data = UserDefaults.standard.value(forKey: "userInfo"){
            
            let userInfo = data as! NSDictionary
            print(userInfo)
            
            let array = userInfo.object(forKey: "record") as! NSArray
            let dict = array.object(at: 0) as! NSDictionary
            print(dict.value(forKey: "username") as! String)
            
            let aStr = String(format: "Welcome, %@", dict.value(forKey: "fname") as! String)
            aFacultyName.text = aStr
            
            let nameStr = String(format: "%@ %@", dict.value(forKey: "fname") as! String,dict.value(forKey: "lname") as! String)
            aFacultyNameFld.text = nameStr
            
            aFacultyEmailFld.text = dict.value(forKey: "advisoremail") as? String
            aFacultyMobileFld.text = dict.value(forKey: "phone") as? String
            
            MBProgressHUD.hide(for: self.view, animated: true)

            
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    

}
