
import UIKit

class RegistrationTypeViewController: UIViewController {

    
    @IBOutlet weak var aStudentIcon: UIImageView!
    @IBOutlet weak var aFacultyIcon: UIImageView!
    
    @IBOutlet weak var aStudentView: UIView!
    @IBOutlet weak var aFultyView: UIView!
    
    @IBAction func aRegisterAsStudent_TouchUpInside(_ sender: Any) {
        
        self.performSegue(withIdentifier: "aRegisterScreenIdentifier", sender: self)

    }
    
    @IBAction func aLoginAsFaculty_TouchUpInside(_ sender: Any) {
        
        self.performSegue(withIdentifier: "FacultyRegistrationIdentifier", sender: self)

    }
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        aStudentIcon.image = UIImage.fontAwesomeIcon(name: .user, textColor: UIColor.black, size: CGSize(width: 24, height: 24))
        aFacultyIcon.image = UIImage.fontAwesomeIcon(name: .graduationCap, textColor: UIColor.black, size: CGSize(width: 24, height: 24))

    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       
        self.navigationItem.title = "Welcome!"

        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.navigationItem.title = ""
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "aRegisterScreenIdentifier") {
            
            let viewController:RegisterViewController = segue.destination as! RegisterViewController
            print(viewController)
            
        }
        if (segue.identifier == "FacultyRegistrationIdentifier") {
            
            let viewController:FacultyRegistrationViewController = segue.destination as! FacultyRegistrationViewController
            print(viewController)
            
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        self.view.endEditing(true)
    }
    
  

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

   
}
