
import UIKit

class ScheduleDetailTableViewCell: UITableViewCell {

    
    @IBOutlet weak var className_Lbl: UILabel!
    @IBOutlet weak var classID_Lbl: UILabel!
    @IBOutlet weak var term_Lbl: UILabel!
    @IBOutlet weak var creditHours_Lbl: UILabel!

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
