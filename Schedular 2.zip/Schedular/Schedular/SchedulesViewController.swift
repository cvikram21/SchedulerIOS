

import UIKit

class SchedulesViewController: UIViewController,UITextFieldDelegate {
    let date = Date()
    let calendar = Calendar.current
    var parentNavigationController : UINavigationController?
    var delegate = UIApplication.shared.delegate as? AppDelegate
    var username = String()
    var term = String()
    var network = DataHelperClass()
    var schedulesArray : NSArray = []
    var activeTextFld = UITextField()
    

    @IBOutlet weak var atimerFld: UITextField!
    //@IBOutlet weak var atermFld: UITextField!

    @IBOutlet weak var aSubmitBtn: UIButton!
    
    @IBAction func submit_TouchupInside(_ sender: Any) {
        
        self.activeTextFld.resignFirstResponder()
        if self.atimerFld.hasText {
            
            
            let month = calendar.component(.month, from: date)
            if(month <= 9 && month >= 1){
                term = "FALL"
            }else{
                term = "SPRING"
            }
            
            ProgressLoader.showLoader(message: "Processing...", delegate: self)
            self.sendRequestForSchedules(username: username, creditHrs: self.atimerFld.text!, term: term)

            //service call
            
        }else{
            
            self.delegate?.showAlert(title: "Warning!", message: "Please enter credit hours")
        }

    }
    
    func sendRequestForSchedules(username:String, creditHrs:String, term:String) -> Void {
        
        //http://localhost/pvdatabase/schedulewithseqcourse.php?username=dakins&credithrs=12&term=SPRING
        let urlString = String(format: "%@/schedulewithseqcourse.php?username=%@&credithrs=%@&term=%@", String.getBaseURL(),username,creditHrs,term)
        print(urlString)
        
        network.getAlltheSchedulesOfStudent(withdelegate: self, url: urlString as NSString)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.atermFld.isHidden = true
        
        network.delegate = self
        
        if let data = UserDefaults.standard.value(forKey: "userInfo"){
            
            let userInfo = data as! NSDictionary
            print(userInfo)
            
            let array = userInfo.object(forKey: "record") as! NSArray
            let dict = array.object(at: 0) as! NSDictionary
            print(dict.value(forKey: "username") as! String)
            username = dict.value(forKey: "username") as! String
            
        }
        
        atimerFld.delegate = self
        //atermFld.delegate = self

        atimerFld.setLeftPaddingPoints(5)
        //atermFld.setLeftPaddingPoints(5)

        self.addDoneButtonOnKeyboard()

        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.navigationItem.title = ""
        self.navigationController?.setNavigationBarHidden(false, animated: animated)

    }
    
    func addDoneButtonOnKeyboard() {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 50))
        doneToolbar.barStyle       = UIBarStyle.default
        let flexSpace              = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem  = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action: #selector(self.doneButtonAction))
        
        var items = [UIBarButtonItem]()
        items.append(flexSpace)
        items.append(done)
        
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        
        self.atimerFld.inputAccessoryView = doneToolbar
        //self.atermFld.inputAccessoryView = doneToolbar

    }
    
    func doneButtonAction() {
        self.activeTextFld.resignFirstResponder()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //MARK:- UITextfield delegate
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        activeTextFld = textField
        

    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        activeTextFld = UITextField()

    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        self.view.endEditing(true)
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "aSchedulesIdentifier") {
            
            if let navigationController = segue.destination as? UINavigationController {
                let viewController = navigationController.topViewController as? SchedulesDetailViewController
                viewController?.schedulesDataArray = sender as! NSArray
                viewController?.term = term
            }
            
        }
        
    }
}

//MARK: DataHelper Delegate

extension SchedulesViewController: DataHelperDelegate {
    
    func getResponse(tag: Int, responseData: AnyObject) {
        if tag == 17{
            ProgressLoader.hideLoader(delegate: self)
            
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["status"] != nil {
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                }else if status == "200"{
                    
                    // print(jsonDict)
                    
                    self.schedulesArray = jsonDict.object(forKey: "response") as! NSArray
                    //print(schedulesArray)
                    
                    self.performSegue(withIdentifier: "aSchedulesIdentifier", sender: schedulesArray)
                    
                    
                }else{
                    
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")

                }
            }else{
                
                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                
            }
            
        }
        
    }
}

