import UIKit
import SwiftyJSON

class SchedulesDetailViewController: UIViewController {

    
    var schedulesDataArray = NSArray()
    var aSpringArray = NSMutableArray()
    var aFallArray = NSMutableArray()
    
    var springRecordsArray = NSArray()
    var fallRecordsArray = NSArray()
    
    var term = String()

    @IBOutlet weak var aTableView: UITableView!
    @IBOutlet weak var aSegmentedControl: UISegmentedControl!
    
    
    @IBAction func done_Action(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)

    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for object in self.schedulesDataArray {
            
            let dictionary = object as? NSDictionary
            let dict = (dictionary?.object(forKey: "semester") as! NSArray).object(at: 0) as! NSDictionary
           // let array = dict.object(forKey: "record") as! NSArray
            let array = (dictionary?.object(forKey: "semester") as! NSArray)
            let attributeValue = dict.value(forKey: "semester_term") as! String
            
            if attributeValue == "SPRING" {
                
                let predicate =
                    NSPredicate(format: "semester_term like %@",attributeValue);
                
                //let filteredArray = schedulesDataArray.filter { predicate.evaluate(with: $0) };
                self.aSpringArray.add(array.filter { predicate.evaluate(with: $0) })

                
            }else if attributeValue == "FALL"{
                
                let predicate =
                    NSPredicate(format: "semester_term like %@",attributeValue);
                self.aFallArray.add(array.filter { predicate.evaluate(with: $0) })
            }

        }
        
        if term == "SPRING" {
            
            aSegmentedControl.selectedSegmentIndex = 0
            
        }else{
            
            aSegmentedControl.selectedSegmentIndex = 1
        }
        
        
        let paramsJSON = JSON(self.aSpringArray)
        print("SPRING = \(paramsJSON)");
        
    
        self.aTableView.delegate = self
        self.aTableView.dataSource = self
        self.aTableView.reloadData()

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
   @IBAction func indexChanged(sender: UISegmentedControl) {
    
    // self.aTableView.setContentOffset(CGPoint.zero, animated: true)
    
    if self.aTableView.numberOfSections > 0 && self.aTableView.numberOfRows(inSection: 0) > 0 {
        self.aTableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
    }

        switch aSegmentedControl.selectedSegmentIndex {
        case 0:
            
            self.aTableView.delegate = self
            self.aTableView.dataSource = self
            self.aTableView.reloadData()
           
        case 1:
            
            self.aTableView.delegate = self
            self.aTableView.dataSource = self
            self.aTableView.reloadData()

        
        default:break
        }
    }
}

extension SchedulesDetailViewController:UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if aSegmentedControl.selectedSegmentIndex == 0 {
            return self.aSpringArray.count>0 ? (self.aSpringArray.count) : 0
        }else{
            return self.aFallArray.count>0 ? (self.aFallArray.count) : 0
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if aSegmentedControl.selectedSegmentIndex == 0 {
            
            self.springRecordsArray = NSArray()
            self.springRecordsArray = ((self.aSpringArray[section] as! NSArray)[0] as! NSDictionary).object(forKey: "record") as! NSArray
            return self.springRecordsArray.count>0 ? (self.springRecordsArray.count) : 0
            
        }else{
            
            self.fallRecordsArray = NSArray()
            self.fallRecordsArray = ((self.aFallArray[section] as! NSArray)[0] as AnyObject).object(forKey: "record") as! NSArray
            return self.fallRecordsArray.count>0 ? (self.fallRecordsArray.count) : 0
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : ScheduleDetailTableViewCell = (tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as? ScheduleDetailTableViewCell)!
        
        let row = indexPath.row
        let section = indexPath.section
        
        if aSegmentedControl.selectedSegmentIndex == 0 {
            
            var dataArray = NSArray()
            dataArray = ((self.aSpringArray[section] as! NSArray)[0] as! NSDictionary).object(forKey: "record") as! NSArray
            
            let dict = dataArray[row] as! NSDictionary
            cell.className_Lbl.text = dict.value(forKey: "className") as! String?
            cell.classID_Lbl.text = dict.value(forKey: "classID") as! String?
            cell.term_Lbl.text = dict.value(forKey: "term") as! String?
            
            let aStr = String(format: "Credit hours : %@", (dict.value(forKey: "creditHours") as! String?)!)
            cell.creditHours_Lbl.text = aStr
           // Credit hours :  3
            
            
        }else{
            
            var dataArray = NSArray()
            dataArray = ((self.aFallArray[section] as! NSArray)[0] as AnyObject).object(forKey: "record") as! NSArray
            
            let dict = dataArray[row] as! NSDictionary
            cell.className_Lbl.text = dict.value(forKey: "className") as! String?
            cell.classID_Lbl.text = dict.value(forKey: "classID") as! String?
            cell.term_Lbl.text = dict.value(forKey: "term") as! String?
            let aStr = String(format: "Credit hours : %@", (dict.value(forKey: "creditHours") as! String?)!)
            cell.creditHours_Lbl.text = aStr
        }
        
    /*    if aSegmentedControl.selectedSegmentIndex == 0 {
            
            let dict = self.springRecordsArray[row] as! NSDictionary
            cell.className_Lbl.text = dict.value(forKey: "className") as! String?
            cell.classID_Lbl.text = dict.value(forKey: "classID") as! String?
            cell.term_Lbl.text = dict.value(forKey: "term") as! String?
            cell.creditHours_Lbl.text = dict.value(forKey: "creditHours") as! String?
            
        }else{
            
            let dict = self.fallRecordsArray[row] as! NSDictionary
            cell.className_Lbl.text = dict.value(forKey: "className") as! String?
            cell.classID_Lbl.text = dict.value(forKey: "classID") as! String?
            cell.term_Lbl.text = dict.value(forKey: "term") as! String?
            cell.creditHours_Lbl.text = dict.value(forKey: "creditHours") as! String?
        }*/

        return cell;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        
        return 96;
    }
    
     func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Section \(section)"
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
     func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let vw = UIView()
        vw.backgroundColor = UIColor.init(colorLiteralRed: 6/255, green: 52/255, blue: 58/255, alpha: 1.0)

        let cell : HeaderTableViewCell = tableView.dequeueReusableCell(withIdentifier: "headerCell") as! HeaderTableViewCell
        
        if aSegmentedControl.selectedSegmentIndex == 0 {
            
            let semester = ((self.aSpringArray[section] as! NSArray)[0] as! NSDictionary).object(forKey: "semester") as! Int
            let aStr = String(format: "SEMESTER %i", semester)
            cell.semester_Lbl.text = aStr
            
        }else{
            
            let semester = ((self.aFallArray[section] as! NSArray)[0] as! NSDictionary).object(forKey: "semester") as! Int
            let aStr = String(format: "SEMESTER %i", semester)
            cell.semester_Lbl.text = aStr
        }
        let rect = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 50) // CGFloat, Double, Int
        cell.contentView.frame = rect
        vw.addSubview(cell.contentView)
        
        
        return vw
    }
    
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        return "Section \(section)"
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let vw = UIView()
        vw.backgroundColor = UIColor.orange
        
        let cell : FooterTableViewCell = tableView.dequeueReusableCell(withIdentifier: "footerCell") as! FooterTableViewCell
        //Scheduled Credit Hours : 14
        
        if aSegmentedControl.selectedSegmentIndex == 0 {
            let semester = ((self.aSpringArray[section] as! NSArray)[0] as! NSDictionary).object(forKey: "Scheduled Credit hours") as! Int
            let aStr = String(format: "Scheduled Credit Hours %i", semester)
            cell.creditHrs_Lbl.text = aStr
            
        }else{
            
            let semester = ((self.aFallArray[section] as! NSArray)[0] as! NSDictionary).object(forKey: "Scheduled Credit hours") as! Int
            let aStr = String(format: "Scheduled Credit Hours : %i", semester)
            cell.creditHrs_Lbl.text = aStr
        }
        
        let rect = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 40) // CGFloat, Double, Int
        cell.contentView.frame = rect
        vw.addSubview(cell.contentView)
        
        return vw
    }



}
