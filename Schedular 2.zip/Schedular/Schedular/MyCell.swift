
import UIKit
import DropDown

class MyCell: DropDownCell {
	
    @IBOutlet weak var suffixLabel: UILabel!
	
}
