
import UIKit

class NavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let viewController: ModifyStudentDetailsViewController = storyboard.instantiateViewController(withIdentifier: "ModifyStudentDetailsViewController") as! ModifyStudentDetailsViewController
        
        self.setViewControllers([viewController], animated: true)


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
