
import UIKit
import MBProgressHUD

class CourcesViewController: UIViewController {

    var parentNavigationController : UINavigationController?
    
    var network = DataHelperClass()
    var courcesArray : NSArray = []
    var selectedCoursesArray = NSMutableArray()
    var username = String()
    var stringArray = NSMutableArray()
    
    
    var delegate = UIApplication.shared.delegate as? AppDelegate
    
    @IBOutlet weak var aTableView: UITableView!
    @IBOutlet weak var submitBtn: UIButton!

    @IBAction func submitRequest_Action(_ sender: Any) {
        
        ProgressLoader.showLoader(message: "Processing...", delegate: self)
        
        if selectedCoursesArray.count > 0 {
            
        for index in selectedCoursesArray{
            print(index)
            
            let courceDetails = self.courcesArray[index as! Int] as! NSDictionary
            let str = courceDetails.value(forKey: "classid") as! String
            stringArray.add(str)
            
            }
            
           // print(stringArray)
            
            let array = stringArray as NSArray
            let stringWithCommas = array.componentsJoined(by: ",")
            print(stringWithCommas)
            
            selectedCoursesArray = NSMutableArray()
            stringArray = NSMutableArray()
            
            self.postSelectedCourcesAsRequest(username: username, courceName: stringWithCommas)
            
        }

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.submitBtn.isEnabled = false
        network.delegate = self
        
        ProgressLoader.showLoader(message: "Processing...", delegate: self)
        
        if let data = UserDefaults.standard.value(forKey: "userInfo"){
            
            let userInfo = data as! NSDictionary
            print(userInfo)
            
            let array = userInfo.object(forKey: "record") as! NSArray
            let dict = array.object(at: 0) as! NSDictionary
            print(dict.value(forKey: "username") as! String)
            username = dict.value(forKey: "username") as! String
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
        
        self.sendGETRequestForAllCources(username: username )

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.navigationItem.title = ""
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    func sendGETRequestForAllCources(username:String) -> Void {
        
        let urlString = String(format: "%@/courses.php?username=%@", String.getBaseURL(),username)
        print(urlString)
        
        network.getAllCources(withdelegate: self, url: urlString as NSString)
        
    }
    
    func postSelectedCourcesAsRequest(username:String, courceName:String) -> Void {
        
        let urlString = String(format: "%@/courses2.php?username=%@&courses=%@,", String.getBaseURL(),username,courceName)
        print(urlString)
        
        network.postSelectedCourcesForApproval(withdelegate: self, url: urlString as NSString)
        
    }

}

extension CourcesViewController:UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.courcesArray.count>0 ? (self.courcesArray.count) : 0

    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : CourcesTableViewCell = (tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as? CourcesTableViewCell)!
        
        
        let courceDetails = self.courcesArray[indexPath.row] as! NSDictionary
        
        cell.courceTypeLbl.text = courceDetails.value(forKey: "classid") as! String?
        cell.courcenameLbl.text = courceDetails.value(forKey: "classname") as! String?
        cell.courceselectionBtn.tag = indexPath.row
        cell.courceselectionBtn.addTarget(self, action: #selector(self.courceSelected(sender:)), for: .touchUpInside)

        if selectedCoursesArray .contains(indexPath.row) {
            cell.courceselectionBtn.setImage(UIImage(named:"check"), for: UIControlState.normal)
        }
        else
        {
            cell.courceselectionBtn.setImage(UIImage(named:"uncheck"), for: UIControlState.normal)
            
        }

        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        
        return 60;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
    }
    
    func courceSelected(sender: UIButton!)
    {
        let value = sender.tag;
        
        if selectedCoursesArray.contains(value)
        {
            selectedCoursesArray.remove(value)
        }
        else
        {
            selectedCoursesArray.add(value)
        }
        
        if selectedCoursesArray.count > 0 {
            
            self.submitBtn.isEnabled = true
        }
        
        print("Selecetd Corces Array \(selectedCoursesArray)")
        
        aTableView.reloadData()
        
    }
    
}

extension CourcesViewController:DataHelperDelegate{
    
    func getResponse(tag: Int, responseData: AnyObject) {
        
        if tag == 12{
            
            ProgressLoader.hideLoader(delegate: self)
            
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                
                // print("JSON: \(responseData)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                }else{
                    
                    // print(jsonDict)
                    
                    courcesArray = NSArray()
                    
                    courcesArray = jsonDict.object(forKey: "record") as! NSArray
                    print(courcesArray)
                    
                    let tblView =  UIView(frame: CGRect.zero)
                    self.aTableView.tableFooterView = tblView
                    self.aTableView.tableFooterView!.isHidden = true
                    self.aTableView.backgroundColor = UIColor.clear
                    
                    aTableView.delegate = self
                    aTableView.dataSource = self
                    self.aTableView.reloadData()
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    
                }
            }else{
                
                
                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                
                
            }
            
        }else if tag == 15{
            
            ProgressLoader.hideLoader(delegate: self)
            
         /*   {
                message = "requested successfully";
                status = 200;
            }*/
            
             print("JSON: \(responseData)")
            selectedCoursesArray = NSMutableArray()
            courcesArray = NSArray()
            let tblView =  UIView(frame: CGRect.zero)
            self.aTableView.tableFooterView = tblView
            self.aTableView.tableFooterView!.isHidden = true
            self.aTableView.backgroundColor = UIColor.clear
            
            aTableView.delegate = self
            aTableView.dataSource = self
            self.aTableView.reloadData()

            self.sendGETRequestForAllCources(username: username )


        }
    }
}
