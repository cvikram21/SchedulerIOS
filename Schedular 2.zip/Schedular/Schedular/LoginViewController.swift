
import UIKit

class LoginViewController: UIViewController {

    @IBOutlet var aContainerView: UIView!
    
    @IBOutlet weak var usernameIcon: UIImageView!
    @IBOutlet weak var aUsernameFld: UITextField!
    
    @IBOutlet weak var passwordIcon: UIImageView!
    @IBOutlet weak var aPasswordFld: UITextField!
    
    @IBOutlet weak var aLoginTypeCheckBox: UIButton!
    @IBOutlet weak var aLoginBtn: UIButton!
    @IBOutlet weak var aRegisterBtn: UIButton!

    var delegate = UIApplication.shared.delegate as? AppDelegate
    
    var isFaculty = Bool()
    var network = DataHelperClass()
    

    func loginASStudent() -> Void {
        
        let parameterDict : NSDictionary  = ["username":self.aUsernameFld.text!,
                                             "password":self.aPasswordFld.text!
                                            ]
        print("params:\(parameterDict)")
        
        let urlString = String(format: "%@/updatedstudentlogin.php?", String.getBaseURL())
        print(urlString)
        
        
        network.loginAsStudent(withdelegate: self, url: urlString as NSString, parameters: parameterDict)
    }
    
    func loginASFaculty() -> Void {
        
        let parameterDict : NSDictionary  = ["username":self.aUsernameFld.text!,
                                             "password":self.aPasswordFld.text!
        ]
        print("params:\(parameterDict)")
        
        let urlString = String(format: "%@/facultylogin.php?", String.getBaseURL())
        print(urlString)
        
        network.loginAsFaculty(withdelegate: self, url: urlString as NSString, parameters: parameterDict)
        
    }
    
    @IBAction func aSelectLoginType_TouchupInside(_ sender: Any) {
        
        if (isFaculty == false)
        {
            aLoginTypeCheckBox.titleLabel?.font = UIFont.fontAwesome(ofSize: 24)
            aLoginTypeCheckBox.setTitle(String.fontAwesomeIcon(name: .checkSquareO), for: .normal)
            isFaculty = true

        }
        else
        {
            aLoginTypeCheckBox.titleLabel?.font = UIFont.fontAwesome(ofSize: 24)
            aLoginTypeCheckBox.setTitle(String.fontAwesomeIcon(name: .squareO), for: .normal)
            isFaculty = false

        }
        

    }
    
    @IBAction func aLoginButton_TouchupInside(_ sender: Any) {
        
      
        
        if self.aUsernameFld.hasText && self.aPasswordFld.hasText {
            
              ProgressLoader.showLoader(message: "Processing...", delegate: self)
            
            if isFaculty == true {
                    loginASFaculty()
            }else{
                self.loginASStudent()
            }
        }else{
            
            self.delegate?.showAlert(title: "Error!", message: "Please enter username and password ")
           
        }
        
        
        
    }
    
    @IBAction func aRegisterButton_TouchupInside(_ sender: Any) {
        
        DataHelperClass().delegate = self

        self.performSegue(withIdentifier: "aRegisterIdentifier", sender: self)

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupCommonLayer()
        
        network.delegate = self

        self.aUsernameFld.delegate = self
        self.aPasswordFld.delegate = self
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
       
        self.navigationItem.title = ""
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    
    func setupCommonLayer() -> Void {
        
        isFaculty = false
        aLoginTypeCheckBox.titleLabel?.font = UIFont.fontAwesome(ofSize: 24)
        aLoginTypeCheckBox.setTitle(String.fontAwesomeIcon(name: .squareO), for: .normal)
        
        usernameIcon.image = UIImage.fontAwesomeIcon(name: .user, textColor: UIColor.black, size: CGSize(width: 24, height: 24))
        passwordIcon.image = UIImage.fontAwesomeIcon(name: .lock, textColor: UIColor.black, size: CGSize(width: 24, height: 24))

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "aHomepageIdentifier") {
            
            if let navigationController = segue.destination as? UINavigationController {
                _ = navigationController.topViewController as? HomePageViewController
            }

            
           // let viewController:HomePageViewController = segue.destination as! HomePageViewController
           // print(viewController)
            
        }else if (segue.identifier == "aRegisterIdentifier"){
            
            let viewController:RegistrationTypeViewController = segue.destination as! RegistrationTypeViewController
            print(viewController)
        }
        
    }
   
}


extension LoginViewController:UITextFieldDelegate{
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        self.view.endEditing(true)
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    
        // When pressing return, move to the next field
        let nextTag = textField.tag + 1
        if let nextResponder = textField.superview?.viewWithTag(nextTag) as UIResponder! {
            nextResponder.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
            //self.aLoginButton_TouchupInside(self.aLoginBtn)
        }
        return false
    }
}

//MARK: DataHelper Delegate

extension LoginViewController: DataHelperDelegate {
    
    func getResponse(tag: Int, responseData: AnyObject) {
        if tag == 1{
            
            ProgressLoader.hideLoader(delegate: self)
            
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                
                print("JSON: \(responseData)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again with valid credentials")
                }else{
                    
                    self.delegate?.defaults.set(jsonDict, forKey: "userInfo")
                    self.performSegue(withIdentifier: "aHomepageIdentifier", sender: self)
                    
                }
            }else{
                
                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again with valid credentials")

            }
            
        }else if tag == 2{
            
            ProgressLoader.hideLoader(delegate: self)

            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                
                print("JSON: \(responseData)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again with valid credentials")
                }else{
                    self.delegate?.defaults.set(jsonDict, forKey: "userInfo")
                    self.performSegue(withIdentifier: "aHomepageIdentifier", sender: self)
                }
            }else{
                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again with valid credentials")

            }
            
        }
        
    }
}


