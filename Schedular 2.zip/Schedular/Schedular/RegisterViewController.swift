
import UIKit
import DropDown

class RegisterViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var aSrollView: UIScrollView!
    var scrollViewContent : CGSize?
    var activeField: UITextField?
    
    var network = DataHelperClass()
    var delegate = UIApplication.shared.delegate as? AppDelegate
    var departmentsArray : NSMutableArray = []
    var serviceSeqIDsArray : NSMutableArray = []
    var advisorIDsArray : NSMutableArray = []
    var temp = String()
    var temp1 = String()
    
    @IBOutlet weak var idFld: UITextField!
    @IBOutlet weak var firstNameFld: UITextField!
    @IBOutlet weak var lastNameFld: UITextField!
    @IBOutlet weak var emailFld: UITextField!
    @IBOutlet weak var aPasswordFld: UITextField!
    @IBOutlet weak var aConfirmPwdFld: UITextField!
    @IBOutlet weak var aPhonenumber: UITextField!
    
    @IBOutlet weak var aDepartmentSelectionBtn: UIButton!
    @IBOutlet weak var aServiceIDSelectionBtn: UIButton!
    @IBOutlet weak var aAdviserIDSelectionBtn: UIButton!
    
    @IBOutlet weak var aSubmitBtn: UIButton!
    
    var isDeptSelected:Bool = false
    var isServiceIDSelected:Bool = false
    var isAdvisorSelected:Bool = false
    
    
    
    let chooseDepartmentDropDown = DropDown()
    let chooseServiceDropDown = DropDown()
    let chooseAdvicerDropDown = DropDown()

    lazy var dropDowns: [DropDown] = {
        return [
            self.chooseDepartmentDropDown,
            self.chooseServiceDropDown,
            self.chooseAdvicerDropDown

        ]
    }()
    
    func setupDefaultDropDown() {
        DropDown.setupDefaultAppearance()
        
        dropDowns.forEach {
            $0.cellNib = UINib(nibName: "DropDownCell", bundle: Bundle(for: DropDownCell.self))
            $0.customCellConfiguration = nil
        }
    }
    
    //MARK: - Setup
    
    func setupDropDowns() {
        setupCenteredDropDown()
    }
    
    func setupCenteredDropDown() {
        
        //Department
        
        chooseDepartmentDropDown.dataSource = (self.departmentsArray as NSArray) as! [String]
        
        // Action triggered on selection
        chooseDepartmentDropDown.selectionAction = { [unowned self] (index, item) in
            
            self.aDepartmentSelectionBtn.setTitle(item, for: .normal)
            
            if self.aAdviserIDSelectionBtn.currentTitle != "Select Adviser ID" {
                self.aAdviserIDSelectionBtn.setTitle("Select Adviser ID", for: UIControlState.normal)
                self.advisorIDsArray = NSMutableArray()
                self.serviceSeqIDsArray = NSMutableArray()
            }
            
            ProgressLoader.showLoader(message: "Processing...", delegate: self)
            
            self.getAllAdviserIDsWithDeptname(deptname: self.aDepartmentSelectionBtn.currentTitle!)
            self.getAllServiceIDs()
        }
       
        //Service Seq
        chooseServiceDropDown.dataSource = (self.serviceSeqIDsArray as NSArray) as! [String]
        
        // Action triggered on selection
        chooseServiceDropDown.selectionAction = { [unowned self] (index, item) in
            self.aServiceIDSelectionBtn.setTitle(item, for: .normal)
        }
      
        //Advisor
        chooseAdvicerDropDown.dataSource = (self.advisorIDsArray as NSArray) as! [String]
        
        // Action triggered on selection
        chooseAdvicerDropDown.selectionAction = { [unowned self] (index, item) in
            self.aAdviserIDSelectionBtn.setTitle(item, for: .normal)
        }
        
    }
    
    @IBAction func aDepartmentSelectionBtn_TouchUpInside(_ sender: Any) {
        
        chooseDepartmentDropDown.show()

    }
    
    @IBAction func aServiceIDSelectionBtn_TouchUpInside(_ sender: Any) {
        
        chooseServiceDropDown.show()
        
    }
    
    @IBAction func aAdviserIDSelectionBtn_TouchUpInside(_ sender: Any) {
        chooseAdvicerDropDown.show()
    }

    @IBAction func aSubmitDetailsToRegister_TouchUpInside(_ sender: Any) {
        
        if self.idFld.hasText && self.firstNameFld.hasText && self.lastNameFld.hasText && self.emailFld.hasText && self.aPasswordFld.hasText && self.aPhonenumber.hasText{
            
           if (self.delegate?.isPwdLenth(password: self.aPasswordFld.text!, confirmPassword: self.aConfirmPwdFld.text!))!{
            
             if (self.delegate?.isPasswordSame(password: self.aPasswordFld.text!, confirmPassword: self.aConfirmPwdFld.text!))! {
                
                if (self.delegate?.validatePhoneNumber(value: self.aPhonenumber.text!))! {
                    
                    if (self.delegate?.isValidStudentEmail(testStr: self.emailFld.text!))! {
                        
                        print("Validate EmailID")
                        self.registerAsStudent()
                    }
                    else{
                        
                        self.delegate?.showAlert(title: "Error!", message: "Please enter valid email, make sure you register with your PV mail!!")
                        return
                    }
                    
                    
                }else{
                    
                    self.delegate?.showAlert(title: "Error!", message: "Please enter valid phone number")
                    return
                }
                
            }else{
                
                self.delegate?.showAlert(title: "Error!", message: "Password should be match")
                return
            }
            
           }else{
            
            self.delegate?.showAlert(title: "Error!", message: "Password should be more than 7 characters")
            return

            }
            
        }else{
            
            self.delegate?.showAlert(title: "Error!", message: "Please fill all the fields ")
        }

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ProgressLoader.showLoader(message: "Processing...", delegate: self)
        
        self.aSrollView.contentInset = UIEdgeInsetsMake(0, 0, 100, 0);
        self.navigationItem.title = "REGISTER AS STUDENT"

        idFld.isUserInteractionEnabled = true

        idFld.delegate = self
        firstNameFld.delegate = self
        lastNameFld.delegate = self
        emailFld.delegate = self
        aPasswordFld.delegate = self
        aConfirmPwdFld.delegate = self
        aPhonenumber.delegate = self
        aSubmitBtn.isEnabled = false
        idFld.setLeftPaddingPoints(5)
        firstNameFld.setLeftPaddingPoints(5)
        lastNameFld.setLeftPaddingPoints(5)
        emailFld.setLeftPaddingPoints(5)
        aPasswordFld.setLeftPaddingPoints(5)
        aConfirmPwdFld.setLeftPaddingPoints(5)
        aPhonenumber.setLeftPaddingPoints(5)

        chooseDepartmentDropDown.tag = aDepartmentSelectionBtn.tag
        chooseServiceDropDown.tag = aServiceIDSelectionBtn.tag
        chooseAdvicerDropDown.tag = aAdviserIDSelectionBtn.tag
       
        network.delegate = self
        
        self.registerForKeyboardNotifications()
        
        dropDowns.forEach { $0.dismissMode = .onTap }
        dropDowns.forEach { $0.direction = .any }
        self.getAllDepartments()
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ModifyStudentDetailsViewController.dismissKeyboard))
        
        //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
        //tap.cancelsTouchesInView = false
        
        view.addGestureRecognizer(tap)

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.navigationItem.title = ""
        self.deregisterFromKeyboardNotifications()
    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }

    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.aSrollView.isScrollEnabled = true
        var info = notification.userInfo!
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height, 0.0)
        
        self.aSrollView.contentInset = contentInsets
        self.aSrollView.scrollIndicatorInsets = contentInsets
        
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.aSrollView.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }
    
    func keyboardWillBeHidden(notification: NSNotification){
        //Once keyboard disappears, restore original positions
        var info = notification.userInfo!
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, -keyboardSize!.height, 0.0)
        self.aSrollView.contentInset = contentInsets
        self.aSrollView.scrollIndicatorInsets = contentInsets
        self.view.endEditing(true)
        //self.aSrollView.isScrollEnabled = false
    }
    
    // MARK: - Delegate
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        // When pressing return, move to the next field
        let nextTag = textField.tag + 1
        if let nextResponder = textField.superview?.viewWithTag(nextTag) as UIResponder! {
            nextResponder.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        self.aSrollView.contentInset = UIEdgeInsetsMake(0, 0, 100, 0);

        return true
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        activeField = textField
    }
    
    func textFieldDidEndEditing(_ textField: UITextField){
       
        activeField = nil
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        return true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "aHomepageIdentifier") {
            
            let viewController:HomePageViewController = segue.destination as! HomePageViewController
            print(viewController)
        }
        
    }
    
    func registerAsStudent() -> Void {
        
        ProgressLoader.showLoader(message: "Processing...", delegate: self)

        
        let department = self.aDepartmentSelectionBtn.currentTitle!
        temp1 = self.aServiceIDSelectionBtn.currentTitle!
        if let spaceRange = temp1.range(of: " ") {
            temp1.removeSubrange(spaceRange.lowerBound..<temp1.endIndex)
        }
        let service = temp1
        let advicer = self.aAdviserIDSelectionBtn.currentTitle!

        let parameterDict : NSDictionary  = ["studentid":self.idFld.text!,
                                             "firstname":self.firstNameFld.text!,
                                             "lastname":self.lastNameFld.text!,
                                             "phone":self.aPhonenumber.text!,
                                             "email":self.emailFld.text!,
                                             "password":self.aPasswordFld.text!,
                                             "deptid":department,
                                             "sciseqid":service,
                                             "advisorid":advicer
        ]
        print("params:\(parameterDict)")
        
      //  http://localhost/pvdatabase/studentsignup.php?studentid="+s1+"&firstname="+s2+"&lastname="+s3+"&email="+s4+"&password="+s5+"&phone="+s6+"&sciseqid="+s7+"&advisorid="+s8+"&deptid="+s9+""
        let urlString = String(format: "%@/studentsignup.php?studentid=%@&firstname=%@&lastname=%@&email=%@&password=%@&phone=%@&sciseqid=%@&advisorid=%@&deptid=%@", String.getBaseURL(),self.idFld.text!,self.firstNameFld.text!,self.lastNameFld.text!,self.emailFld.text!,self.aPasswordFld.text!,self.aPhonenumber.text!,service,advicer,department)
        print(urlString)
        
        network.registerAsStudent(withBaseURL: urlString as NSString, parameters: parameterDict)
        
    }
    
    func getAllDepartments() -> Void {
        
        let urlString = String(format: "%@/updateddepartments.php?", String.getBaseURL())
        print(urlString)
        
        network.getAllDepartments(withdelegate: self, url: urlString as NSString)
        
    }
    
    //http://localhost/pvdatabase/updatedadvisors.php?department=”+DepartmentID+”
    func getAllServiceIDs() -> Void {
        
        let urlString = String(format: "%@/scienceseq.php?", String.getBaseURL())
        print(urlString)
        
        network.getAllServiceIDsWithUsername(withdelegate: self, url: urlString as NSString)
        
    }
    
    func getAllAdviserIDsWithDeptname(deptname:String) -> Void {
        
       // http://localhost/pvdatabase/updatedadvisors.php?department=COMPUTERSCIENCE
        //        let department = self.aDepartmentSelectionBtn.currentTitle

        
        let urlString = String(format: "%@/updatedadvisors.php?department=%@", String.getBaseURL(),deptname)
        print(urlString)
        
        network.getAllAdviserIDsWithServiceID(withdelegate: self, url: urlString as NSString)
        aSubmitBtn.isEnabled = true
    }

}

//MARK: DataHelper Delegate

extension RegisterViewController: DataHelperDelegate {
    
    func getResponse(tag: Int, responseData: AnyObject) {
        
        ProgressLoader.hideLoader(delegate: self)

        if tag == 3{
            
            ProgressLoader.hideLoader(delegate: self)
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again with valid credentials")
                }else{
                    
                    let dataArray = jsonDict.object(forKey: "record") as! NSArray
                    
                    print("JSON: \(dataArray)")

                    
                    for object in dataArray {
                        let  dictionary = object as! NSDictionary
                        let deptname = dictionary.value(forKey: "deptname") as! NSString
                        departmentsArray.add(deptname)
                    }
                    
                    self.setupDropDowns()
                    

                }
            }else{
                
                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
            }
        }
        
        if tag == 18{
            
            ProgressLoader.hideLoader(delegate: self)
            
            //{"record":[{"sciseqid":"sciseq1"},{"sciseqid":"sciseq2"},{"sciseqid":"sciseq3"}],"status":"200"}
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                
                // print("JSON: \(responseData)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                }else{
                    
                    let dataArray = jsonDict.object(forKey: "record") as! NSArray
                    
                    for object in dataArray {
                        let  dictionary = object as! NSDictionary
                        let servicename = dictionary.value(forKey: "sciseqid") as! NSString
                        if(servicename == "sciseq1"){
                            temp = (servicename as String)+" (2_CHEM_and_1_PHYS)"
                        }
                        else if(servicename == "sciseq2"){
                            temp = (servicename as String)+" (2_PHYS_and_1_CHEM)"
                        }
                        else if(servicename == "sciseq3"){
                            temp = (servicename as String)+" (1_BIOL_and_2_PHYS)"
                        }
                        serviceSeqIDsArray.add(temp)
                    }
                    self.setupDropDowns()
                    
                }
            }else{
                
                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")

            }
        }
        
        if tag == 19{
            
            ProgressLoader.hideLoader(delegate: self)

            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                
                // print("JSON: \(responseData)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                }else{
                    
                    let dataArray = jsonDict.object(forKey: "record") as! NSArray
                    
                    for object in dataArray {
                        let  dictionary = object as! NSDictionary
                        let advisorname = dictionary.value(forKey: "username") as! NSString
                        advisorIDsArray.add(advisorname)
                    }
                    
                    self.setupDropDowns()
                    
                }
            }else{
                
                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
            }
        }
        
        if tag == 2{
            
            ProgressLoader.hideLoader(delegate: self)
            
             print("Sign up JSON: \(responseData)")

            let jsonDict = responseData as! NSDictionary
            if jsonDict["status"] != nil {
                let status = jsonDict.value(forKey: "status") as! NSString
                let message = jsonDict.value(forKey: "message") as! NSString
                if(status == "400" && message == "registered"){
                    self.delegate?.showAlert(title: "Error!", message: "Email already registered")
                }
                else if status == "400"{
                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                }else{
                    self.delegate?.showAlert(title: "Success!", message: "Your account has been successfully registered, please check your email to verify your account")
                    //ay = jsonDict.object(forKey: "record") as! NSArray
                    self.performSegue(withIdentifier: "aHomeidentifier", sender: self)
                }
            }else{
                
                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                
            }
        }
        
    }
}


