
import UIKit
import MBProgressHUD

class ModifyStudentDetailsViewController: UIViewController {

    var network = DataHelperClass()
    var studentName = String()
    var facultyName = String()
    var delegate = UIApplication.shared.delegate as? AppDelegate

    @IBOutlet weak var studentNameLbl: UILabel!
    @IBOutlet weak var emailFld: UITextField!
    @IBOutlet weak var mobileFld: UITextField!
    @IBOutlet weak var degreePlanYearFld: UITextField!
    @IBOutlet weak var modifyBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let loadingNotification = MBProgressHUD.showAdded(to: self.view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.indeterminate
        loadingNotification.label.text = "Loading..."
        
        network.delegate = self
        
        emailFld.isUserInteractionEnabled = false
        mobileFld.isUserInteractionEnabled = false
        degreePlanYearFld.isUserInteractionEnabled = false
        
        emailFld.setLeftPaddingPoints(5)
        mobileFld.setLeftPaddingPoints(5)
        degreePlanYearFld.setLeftPaddingPoints(5)
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ModifyStudentDetailsViewController.dismissKeyboard))
        
        //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
        //tap.cancelsTouchesInView = false
        
        view.addGestureRecognizer(tap)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.sendGETRequestForStudentDetails(studentname: studentName )
    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    func sendGETRequestForStudentDetails(studentname:String) -> Void {
        
        let urlString = String(format: "%@/displaystudentinfo.php?username=%@", String.getBaseURL(),studentname)
        print(urlString)
        
        network.getStudentDetailsWithStudentName(withdelegate: self, url: urlString as NSString)
        
    }
    
    func updateStudentDetails(username:String) -> Void {
        
       // http://localhost/pvdatabase/facultystudentupdate.php?username=kibellam&studentname=bwallace8&degreeplan=2015

        let urlString = String(format: "%@/facultystudentupdate.php?username=%@&studentname=%@&degreeplan=%@", String.getBaseURL(),username,studentName,degreePlanYearFld.text!)
        print(urlString)
        
        network.updateStudentDetailsWithStudentName(withdelegate: self, url: urlString as NSString)
        
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func modify_Action(_ sender: Any) {
        
        
        if modifyBtn.currentTitle == "MODIFY" {
            emailFld.isUserInteractionEnabled = false
            mobileFld.isUserInteractionEnabled = false
            degreePlanYearFld.isUserInteractionEnabled = true
            degreePlanYearFld.becomeFirstResponder()
            modifyBtn.setTitle("UPDATE", for: .normal)
        }else{
            
            emailFld.isUserInteractionEnabled = false
            mobileFld.isUserInteractionEnabled = false
            degreePlanYearFld.isUserInteractionEnabled = false
            modifyBtn.setTitle("MODIFY", for: .normal)
            
            self.updateStudentDetails(username: facultyName)

        }
    }

    @IBAction func cancel_Action(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)

    }
    
    // MARK: - Helpers
    
    func showSuccessAlert(title: String, message:String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            self.dismiss(animated: false, completion: nil)
        }))
        self.present(alert, animated: true, completion: nil)
        
        
    }
   
}

//MARK: DataHelper Delegate

extension ModifyStudentDetailsViewController: DataHelperDelegate {
    
    func getResponse(tag: Int, responseData: AnyObject) {
        if tag == 5{
            let jsonDict = responseData as! NSDictionary
            
            if jsonDict["record"] != nil {
                
                // print("JSON: \(responseData)")
                
                let status = jsonDict.value(forKey: "status") as! NSString
                if status == "400"{
                    
                    MBProgressHUD.hide(for: self.view, animated: true)

                    self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
                }else{
                    
                    
                    let dataArray = jsonDict.object(forKey: "record") as! NSArray
                    
                    let dict = dataArray.object(at: 0) as! NSDictionary
                    print(dict)

                    let aStr = String(format: "Change degreeplan year of %@", studentName)
                    studentNameLbl.text = aStr

                    emailFld.text = dict.value(forKey: "emailid") as? String
                    mobileFld.text = dict.value(forKey: "phone") as? String
                    degreePlanYearFld.text = dict.value(forKey: "degreeplan") as? String
                    self.view.setNeedsDisplay()
                    
                    MBProgressHUD.hide(for: self.view, animated: true)

                }
            }else{
                
                MBProgressHUD.hide(for: self.view, animated: true)

                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")
            }
            
        }else if tag == 6{
            
            let jsonDict = responseData as! NSDictionary
            
            let status = jsonDict.value(forKey: "status") as? String
            let message = jsonDict.value(forKey: "message") as? String

            
            if status == "200" {
                self.showSuccessAlert(title: "Success!", message: message!)
            }else{
                self.delegate?.showAlert(title: "Error!", message: "It's look like some thing went wrong!, Please try again later")

            }

        }
        
    }
}




